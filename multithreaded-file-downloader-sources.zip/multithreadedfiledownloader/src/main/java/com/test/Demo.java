package com.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

public class Demo {

	public static void main(String[] args) {
		validateInputs(args);
		launch(args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]));
	}

	private static void validateInputs(String[] commandLineArguments) {
		System.out.println("commandLineArguments: "+ Arrays.toString(commandLineArguments));
		if(commandLineArguments.length == 0)
			throw new IllegalArgumentException("No arguments were passed");
		if(commandLineArguments[0] == null)
			throw new IllegalArgumentException("URL cannot be null. Please input a webPageUrl");
		if(commandLineArguments[1] == null)
			throw new IllegalArgumentException("fetch count cannot be null. Please input fetchCount");
		if(commandLineArguments[2] == null)
			throw new IllegalArgumentException("threadCount cannot be null. Please input threadCount");
		if(Integer.parseInt(commandLineArguments[2]) > Runtime.getRuntime().availableProcessors())
			throw new IllegalArgumentException("threadCount cannot be greater than available processors - "+Runtime.getRuntime().availableProcessors());
	}

	private static void launch(String webPageUrl, int numberOfIterations, int threadCount) {
		if(threadCount > Runtime.getRuntime().availableProcessors())
			threadCount = Runtime.getRuntime().availableProcessors();
		ExecutorService executorService = Executors.newFixedThreadPool(threadCount);
		// its kind of an immutable class, we dont need multiple copies
		FileDownloadTask fileDownloadTask = new FileDownloadTask(webPageUrl, numberOfIterations);
		List<Callable<Void>> list = new ArrayList<>(threadCount);
		IntStream.range(0, threadCount).forEach(i -> list.add(fileDownloadTask));
		try {
			executorService.invokeAll(list);
		} catch(Exception exception) {
			System.out.println("Exception while running download");
			exception.printStackTrace();
		} finally {
			executorService.shutdown();
		}
	}

}
