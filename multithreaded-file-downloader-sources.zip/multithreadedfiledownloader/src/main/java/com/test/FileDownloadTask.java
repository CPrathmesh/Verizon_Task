package com.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.concurrent.Callable;

public class FileDownloadTask implements Callable<Void> {

	private int iterations;
	private String webPageUrl;

	FileDownloadTask(String webPageUrl, int iterations) {
		this.iterations = iterations;
		this.webPageUrl = webPageUrl;
	}

	public Void call() throws Exception {
		for(int i = 1; i <= iterations; i++)
			download(webPageUrl, i);
		return null;
	}

	private void download(String webPageUrl, int requestId) throws IOException {
		Thread.currentThread().setName("thread"+requestId);
		long startTime = System.currentTimeMillis();
		try(InputStreamReader inputStreamReader = new InputStreamReader(new URL(webPageUrl).openStream());
				BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
				BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("file.html-"+System.currentTimeMillis()))) {
			String line;
			while ((line = bufferedReader.readLine()) != null)
				bufferedWriter.write(line);
			System.out.println(String.format("request-%d/%s", requestId, Thread.currentThread().getName())+", HTTP 200, "+(System.currentTimeMillis() - startTime)+" milliseconds");
		} catch (IOException ie) {
			System.out.println("IOException raised");
			throw ie;
		}
	}

}
